# DEC-Keras
Deep Embedding Clustering in Keras [https://arxiv.org/abs/1511.06335]

Similar to https://github.com/dmlc/mxnet/blob/master/example/dec/dec.py, but using Theano/Tensorflow backend rather than MXNET.
